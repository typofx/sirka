<?php include $_SERVER['DOCUMENT_ROOT'] . '/plataforma/panel/is_logged.php'; ?>
<? include $_SERVER['DOCUMENT_ROOT'] . '/.scr/conexao.php'; ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <title>Panel - Listing places</title>

    <style>
        body {
            font-family: monospace;
            background-color: #D3D3D3;
        }

        table.dataTable {
            width: 100%;

            border-collapse: collapse;
            /* Remove espaços entre bordas */
        }

        table.dataTable th,
        table.dataTable td {
            padding: 8px 12px;
            text-align: left;
            border: 1px solid black;
            /* Adiciona borda entre as células */
        }

        table.dataTable th {
            background-color: #696969;
            border-bottom: 1px solid black;
            /* Destaque para o cabeçalho */
        }

        table.dataTable tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        table.dataTable tbody tr:hover {
            background-color: #f1f1f1;
            /* Destaque ao passar o mouse */
        }

        /* Paginação */
        .dataTables_wrapper .dataTables_paginate .paginate_button {
            padding: 0;
            margin: 0;
            border: none;
            background: none;
            cursor: pointer;
        }

        /* Classes utilitárias */
        .invisible {
            display: none;
        }

        .pointer {
            cursor: pointer;
        }



        .colored-cell span {
            margin-right: 9px;
            /* Espaçamento à direita de cada elemento */
        }

        th.no-wrap-icons {
            white-space: nowrap;
            /* Evita quebra de linha no conteúdo do <th> */
        }

        th.no-wrap-icons i {
            display: inline-block;
            font-size: 10px;
            margin-right: 2px;
            vertical-align: middle;
        }

        .status-link {

            align-items: center;
            text-decoration: none;


            border-radius: 4px;
            font-size: 12px;

        }

        .status-link img {
            margin-right: 4px;
        }
    </style>

    <style>
        .hidden-column {
            display: none;
        }
    </style>

    <script>
        function hideCountry() {
            const listElement = document.querySelectorAll(".cl-country");
            for (let i = 0; i < listElement.length; i++) {
                listElement[i].classList.toggle("invisible");
            }
        }

        function hideAccess() {
            const listElement = document.querySelectorAll(".cl-access");
            for (let i = 0; i < listElement.length; i++) {
                listElement[i].classList.toggle("invisible");
            }
        }

        function hideType() {
            const listElement = document.querySelectorAll(".cl-type");
            for (let i = 0; i < listElement.length; i++) {
                listElement[i].classList.toggle("invisible");
            }
        }

        function hideEmail() {
            const listElement = document.querySelectorAll(".cl-email");
            for (let i = 0; i < listElement.length; i++) {
                listElement[i].classList.toggle("invisible");
            }
        }

        function hideTelegram() {
            const listElement = document.querySelectorAll(".cl-telegram");
            for (let i = 0; i < listElement.length; i++) {
                listElement[i].classList.toggle("invisible");
            }
        }

        function hideRank() {
            const listElement = document.querySelectorAll(".cl-rank");
            for (let i = 0; i < listElement.length; i++) {
                listElement[i].classList.toggle("invisible");
            }
        }
    </script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">


</head>

<body>
    <br>
    <br>
    <br>
    <a href="listingplatform.insert.php">[Add new record]</a>
    <a href="<?php include $_SERVER['DOCUMENT_ROOT'] . '/plataforma/panel/main.php'; ?>">[Back]</a>




    
    <?php
    //include 'listingplatform.conexao.php';

    $sql = "SELECT * FROM granna80_bdlinks.links ORDER BY `Score` DESC, Access DESC, Rank DESC;";

    $result = $conn->query($sql);
    $links_data = [];

    function getTXTcolor($value)
    {

        if ($value == NULL) {
            return 'color: gray;';
        } elseif ($value == true) {
            return 'color: green;';
        } else {
            return 'color: red;';
        }
    }

    function setBGcolor($score)
    {
        $score = floatval($score);

        if ($score >= 70 && $score <= 100) {
            return 'background-color: #90EE90;';
        } elseif ($score >= 45 && $score < 70) {
            return 'background-color: #fdfd96;';
        } else {
            return 'background-color: #ff6961;';
        }
    }

    function getAccessIcon($access)
    {
        $access = intval($access);
        $animalIcon = '';
        switch ($access) {
            case 0:
                $animalIcon = '<img src="https://www.plata.ie/images/flags/un.png" height="17" width="17" >';
                break;
            case 1:
                $animalIcon = '<img src="img/notfound.png">';
                break;
            case 1000:
                $animalIcon = '<img src="img/icon_shrimp.png">';
                break;
            case 10000:
                $animalIcon = '<img src="img/icon_crab.png">';
                break;
            case 100000:
                $animalIcon = '<img src="img/icon_fish.png">';
                break;
            case 1000000:
                $animalIcon = '<img src="img/icon_shark.png">';
                break;
            case 10000000:
                $animalIcon = '<img src="img/icon_whale.png">';
                break;
            default:
                $animalIcon = '?';
                break;
        }

        // Retorna apenas o emoji/imagem original
        return '<span style="font-size: 20px;" title="">' . $animalIcon . '</span>';
    }

    //  function verificaStatusSite($url)
    //  {
    //  $headers = @get_headers($url);
    
    //  if ($headers) {
    // Extrai o código de status HTTP
    //   $statusCode = explode(' ', $headers[0])[1];
    
    // Array de códigos de status que consideramos como "Online"
    //    $onlineStatusCodes = array('200', '401', '403', '500', '308');
    //
    //      if (in_array($statusCode, $onlineStatusCodes)) {
    //          return '<span style="color: green;">Online HTTP CODE: ' . $statusCode . '</span>';
    //      } else {
    //          return '<span style="color: red;">Offline HTTP CODE:' . $statusCode . '</span>';
    //       }
    //   } else {
    //        return '<span style="color: red;">Failed to get headers</span>';
    //    }
    // }
    


    if ($result->num_rows > 0) {
        echo '<style>
            .colored-cell {
                padding: 0px; /* Add padding for better visibility */
                text-align: center;
                
            }
          </style>';

        //tabela inicio
    

        echo '<center>
        <div>
            <label>
                <input type="checkbox" id="toggleObs1" onchange="toggleColumn(\'editedby-column\')"> Last Edited By
            </label>
            <label>
                <input type="checkbox" id="toggleObs1" onchange="toggleColumn(\'obs1-column\')"> Obs1
            </label>
            <label style="margin-left: 10px;">
                <input type="checkbox" id="toggleObs2" onchange="toggleColumn(\'obs2-column\')"> Obs2
            </label>
        </div>
        <table id="example" style="width: 70%;">';

        ?>

        <thead>
            <tr>
                <th>ID</th>
                <th><i title="Desktop">&nbsp;&nbsp;</i></th> 
                <!-- <th><i title="Mobile"></i></th>  Mobile -->

                <th>&nbsp;%&nbsp;</th>
                <th>Platform</th>
                <th class="pointer cl-country"><a onclick="hideCountry()"> </a></th> 

                <!-- Gear column header - COMMENTED OUT to prevent table misalignment
                <th style="display:none;"></th>
                -->

                <th class="pointer cl-type"><a onclick="hideType()">Type</a></th>
                <th class="pointer cl-access"><a onclick="hideAccess()"></a></th>
                <th class="no-wrap-icons">

                </th>

                <th class="obs1-column">Obs1</th>
                <th class="obs2-column">Obs2</th>


                <th>Updated&nbsp;(UTC)</th>
                <th class="editedby-column">Last Edited By</th>
                <th>Actions</th>
            </tr>
        </thead>

        <tbody>
            <?php
            $cont = 1;
            while ($row = $result->fetch_assoc()) {

                $links_data[] = [
                    "ID" => intval($cont),
                    "Desktop" => $row["Desktop"],
                    "Mobile" => $row["Mobile"],
                    "Platform" => !empty($row["Platform"]) ? $row["Platform"] : "update",
                    "link" => $row["Link"],
                    "Score" => round(floatval($row["Score"]), 4),
                    "Icone" => $row["logo"],
                    "Full-Logo" => $row["full_logo"],
                    "Type" => $row["Type"],
                    "Access" => intval($row["Access"]),
                    "Country" => $row["Country"],
                    "Rank" => $row["Rank"],
                    "MarketCap" => $row["MarketCap"],
                    "Liquidity" => $row["Liquidity"],
                    "FullyDilutedMKC" => $row["FullyDilutedMKC"],
                    "CirculatingSupply" => $row["CirculatingSupply"],
                    "MaxSupply" => $row["MaxSupply"],
                    "TotalSupply" => $row["TotalSupply"],
                    "Price" => $row["Price"],
                    "Graph" => $row["Graph"],
                    "Holders" => $row["Holders"],
                    "TokenLogo" => $row["TokenLogo"],
                    "SocialMedia" => $row["SocialMedia"],
                    "MetamaskButton" => $row["MetamaskButton"],
                    "Obs1" => $row["Obs1"],
                    "Obs2" => $row["Obs2"],
                    "LastUpdated" => date("d-m-Y H:i", strtotime($row["last_updated"])),
                    "EditedBy" => $row["editedBy"]
                ];

                $update = 'Update';
                echo '<tr>';
                echo '<td><center>' . intval($cont) . '</center></td>';

                echo '<td class="colored-cell">';

                if ($row["Listed"] == true) {
                    $colorDesktop = ($row["Desktop"] == true) ? 'green' : 'gray';
                    echo '<i class="fas fa-desktop" title="Desktop" style="color: ' . $colorDesktop . ';"></i>';
                    $colorMobile = ($row["Mobile"] == true) ? 'green' : 'gray';
                    echo '<i class="fas fa-mobile-alt" title="Mobile" style="color: ' . $colorMobile . ';"></i>';
                } else {
                    echo ' ';
                }
                echo '</td>';

                echo '<td class="colored-cell"><center>' . round(floatval($row["Score"]), 4) . '</center></td>';
                echo '<td class="colored-cell"><center><a href="' . $row["Link"] . '" target="_blank">' . (!empty($row["Platform"]) ? $row["Platform"] : "update") . '</a></center></td>';
                // Country flag - next to Platform
                echo '<td class="cl-country" ><center><img src="https://www.plata.ie/images/flags/' . $row["Country"] . '.png" alt="' . $row["Country"] . '" height="20" width="20"></center></td>';

                /* Gear status button - COMMENTED OUT to prevent table misalignment
                echo '<td class="colored-cell" style="display:none; ' . setBGcolor($row["Score"] ?? "") . '">
                <a href="listingplatform.new_status.php?id=' . $row["ID"] . '" target="_blank" class="status-link">
                    <i class="fa-solid fa-gear" style="color: ' .
                    (strpos($row["status"], 'green') !== false ? 'green' : 'red') . '; font-size: 16px;"></i>
                </a>
                </td>';
                */



                echo '<td class="cl-type"><center>' . $row["Type"] . '</center></td>';
                echo '<td class="cl-access"><center>' . getAccessIcon($row["Access"]) . '</center></td>';

                echo '<td class="colored-cell" style="white-space: nowrap;">';

                echo '<span style="' . getTXTcolor($row["Rank"] ?? "") . '; font-size: 17px;"><i class="fas fa-trophy" title="Rank"></i></span>'; // added Rank icon 
                echo '<span style="' . getTXTcolor($row["MarketCap"] ?? "") . '; font-size: 17px;"><i class="fas fa-chart-line" title="Market Cap"></i></span>';
                echo '<span style="' . getTXTcolor($row["Liquidity"] ?? "") . ';"><i class="fas fa-water" title="Liquidity"></i></span>';
                echo '<span style="' . getTXTcolor($row["FullyDilutedMKC"] ?? "") . ';"><i class="fas fa-coins" title="Fully Diluted Market Cap"></i></span>';
                echo '<span style="' . getTXTcolor($row["CirculatingSupply"] ?? "") . ';"><i class="fas fa-circle" title="Circulating Supply"></i></span>';
                echo '<span style="' . getTXTcolor($row["MaxSupply"] ?? "") . ';"><i class="fas fa-layer-group" title="Max Supply"></i></span>';
                echo '<span style="' . getTXTcolor($row["TotalSupply"] ?? "") . ';"><i class="fas fa-cubes" title="Total Supply"></i></span>';
                echo '<span style="' . getTXTcolor($row["Price"] ?? "") . ';"><i class="fas fa-dollar-sign" title="Price"></i></span>';
                echo '<span style="' . getTXTcolor($row["Graph"] ?? "") . ';"><i class="fas fa-chart-bar" title="Graph"></i></span>';
                echo '<span style="' . getTXTcolor($row["Holders"] ?? "") . ';"><i class="fas fa-users" title="Holders"></i></span>';
                echo '<span style="' . getTXTcolor($row["TokenLogo"] ?? "") . ';"><i class="fas fa-shield-alt" title="Token Logo"></i></span>';
                echo '<span style="' . getTXTcolor($row["SocialMedia"] ?? "") . ';"><i class="fas fa-share-alt" title="Social Media"></i></span>';
                echo '<span style="' . getTXTcolor($row["MetamaskButton"] ?? "") . ';"><i class="fas fa-wallet" title="Metamask"></i></span>';
                echo '</td>';



                echo '<td class="obs1-column">' . $row["Obs1"] . '</td>';
                echo '<td class="obs2-column">' . $row["Obs2"] . '</td>';

                echo '<td>' . date("d/m/y H:i", strtotime($row["last_updated"] ?? "")) . '</td>';
                echo '<td class="editedby-column">' . $row["editedBy"] . '</td>';

                // Ações (Telegram, Email, Edit, Delete)
                echo '<td style="white-space: nowrap;">
                    <a href="https://t.me/' . $row["Telegram"] . '" target="_blank"><img src="https://www.plata.ie/images/telegram-logo.svg" alt="Telegram" height="20"></a>
                    <a href="mailto:' . $row["Email"] . '" target="_blank"><img src="https://www.plata.ie/images/sheet-icon-email.png" alt="Email" width="15" height="15"></a>
                    <a href="listingplatform.edit.php?id=' . $row["ID"] . '"><img src="https://www.plata.ie/plataforma/img/sheet-icon-edit.png" width="15" height="15"></a>
                    <a href="listingplatform.delete.php?id=' . $row["ID"] . '" onclick="return confirm(\'Are you sure you want to delete this record?\')"><img src="https://www.plata.ie/plataforma/img/sheet-icon-delete.png" width="15" height="15"></a>

                    </td>';

                echo '</tr>';
                $cont++;
            }
            ?>
        </tbody>
        </table>
        </center>

        <?php
        $json_data = json_encode($links_data, JSON_NUMERIC_CHECK);


        $file = 'links_data.json';

        if (file_put_contents($file, $json_data)) {
            echo "JSON data has been stored in 'links_data.json'.";
        } else {
            echo "Error writing JSON data to the file.";
        }

        echo "<p>JSON file successfully created: <a href='links_data.json' target='_blank'>[JSON]</a></p>";
    } else {
        echo "No results found.";
    }

    $conn->close();
    ?>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

    <style>
        /* Define largura reduzida para colunas específicas */
        .narrow-column {
            width: 5px !important;
            /* Força a largura desejada */
            min-width: 5px !important;
            /* Garante o mínimo */
            max-width: 5px !important;
            /* Evita aumentar */
            text-align: center;
        }
    </style>
    <script>
        function toggleColumn(columnClass) {
            const elements = document.querySelectorAll('.' + columnClass);
            elements.forEach(element => {
                element.style.display = (element.style.display === 'none') ? '' : 'none';
            });
        }

        document.addEventListener("DOMContentLoaded", function () {
            // Inicialmente ocultar as colunas Obs1 e Obs2
            toggleColumn('obs1-column');
            toggleColumn('obs2-column');
            toggleColumn('editedby-column');
        });
    </script>

    <script>
        $(document).ready(function () {
            $('#example').DataTable({
                // Configurações adicionais
                "paging": true,
                "pageLength": 250,
                "lengthMenu": [25, 100, 200, 250],
                "searching": true, // Caixa de busca
                "info": true, // Informação de páginas
                "autoWidth": false, // Desativa ajuste automático de largura

            });
        });
    </script>

</body>

</html>